    % author: Jason Lee
    % HDBn decoding
    % input:encoded_signal, n, encoded_pre_signal(1 or -1)
    % output:decoded_signal
    
    decoded_signal = zeros(1, length(encoded_signal)); % initialize
    zero_count = 0; 
    last_nonzero_polarity = encoded_pre_signal;
    
    for i = 1:length(encoded_signal)
        if encoded_signal(i) == 0
            zero_count = zero_count + 1;
        else % detected '+-1'
            if encoded_signal(i) ~= last_nonzero_polarity
                decoded_signal(i) = 1;
                % update polarity
                last_nonzero_polarity = encoded_signal(i);
            else
                decoded_signal(i) = 0;
                if zero_count == n-1
                    decoded_signal(i-n)=0;
                end
            end
            zero_count = 0;
        end
    end
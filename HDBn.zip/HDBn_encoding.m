% author: Jason Lee
% HDBn encoding
% input:original_signal, n, original_pre_signal
% output:encoded_signal
% even substitution mode

encoded_signal = zeros(1, length(original_signal));
last_polarity = original_pre_signal;
last_v_polarity = 1;
zero_count = 0;
start_with_n_zeroes_flag = 1;
first_substitute_flag = 1;
for i = 1:length(original_signal)
    if(original_signal(i) == 1 && i < n+2)
        start_with_n_zeroes_flag = 0;
    end
    if original_signal(i) == 1
        zero_count = 0;
        encoded_signal(i) = -last_polarity;
        last_polarity = -last_polarity;
    else
        zero_count = zero_count + 1;
        if zero_count == n+1
            if start_with_n_zeroes_flag == 1
                encoded_signal(i-n) = -1;
                encoded_signal(i) = -1;
                last_v_polarity = -1;
                last_polarity = -1;
                start_with_n_zeroes_flag = 0;
                first_substitute_flag = 0;
            else
                if first_substitute_flag == 0
                    if last_v_polarity == 1 % should be 0...0 -V
                        if last_polarity == 1 % need to add -B
                            encoded_signal(i-n) = -1;
                            encoded_signal(i) = -1;
                            last_v_polarity = -1;
                            last_polarity = -1;
                        else % not adding -B
                           % encoded_signal(i-n) = 0;
                            encoded_signal(i) = -1;
                            last_v_polarity = -1;
                            last_polarity = -1;
                        end
                    else % should be 0...0 V
                        if last_polarity == -1 % need to add B
                            encoded_signal(i-n) = 1;
                            encoded_signal(i) = 1;
                            last_v_polarity = 1;
                            last_polarity = 1;
                        else % not adding B
                            encoded_signal(i) = 1;
                            last_v_polarity = 1;
                            last_polarity = 1;
                        end
                    end
                else
                    first_substitute_flag = 0;
                    if last_polarity == 1
                        encoded_signal(i-n) = -1;
                        encoded_signal(i) = -1;
                        last_v_polarity = -1;
                        last_polarity = -1;
                    else
                        encoded_signal(i-n) = 1;
                        encoded_signal(i) = 1;
                        last_v_polarity = 1;
                        last_polarity = 1;
                    end
                end      
            end
            zero_count = 0;
        else
            encoded_signal(i) = 0;
        end
    end
end
